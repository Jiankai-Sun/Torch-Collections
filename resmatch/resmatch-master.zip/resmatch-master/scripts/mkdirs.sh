#! /bin/sh

mkdir -p tmp
mkdir -p out
mkdir -p storage
mkdir -p results
cd storage
mkdir -p net
mkdir -p net/mc
mkdir -p net/mc/debug
mkdir -p net/disparity
mkdir -p net/disparity/debug
mkdir -p data.kitti.rgb/disparity
mkdir -p data.kitti2015.rgb/disparity
cd ..
